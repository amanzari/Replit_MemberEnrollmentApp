const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Request logging middleware
app.use((req, res, next) => {
  if (req.method === 'POST') {
    console.log('=== Request Details ===');
    console.log('URL:', req.url);
    console.log('Headers:', JSON.stringify(req.headers, null, 2));
    console.log('Body:', JSON.stringify(req.body, null, 2));
  }
  next();
});

// MongoDB Connection with better error handling
const connectDB = async () => {
  try {
    // MongoDB connection string with options
    const mongoURI = 'mongodb://127.0.0.1:27017/member-enrollment?directConnection=true&serverSelectionTimeoutMS=2000&appName=member-enrollment-app';
    
    const conn = await mongoose.connect(mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
      family: 4  // Use IPv4, skip trying IPv6
    });
    
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    console.log('Database:', conn.connection.name);
    return true;
  } catch (error) {
    console.error('MongoDB connection error:', error);
    console.log('Connection string used:', mongoURI);
    console.log('Please make sure MongoDB is installed and running on your system.');
    console.log('You can download MongoDB from: https://www.mongodb.com/try/download/community');
    return false;
  }
};

// Connect to MongoDB
let isMongoConnected = false;
connectDB().then(connected => {
  isMongoConnected = connected;
  if (connected) {
    console.log('Successfully connected to MongoDB');
  } else {
    console.log('Failed to connect to MongoDB');
  }
});

// Define Member Schema
const memberSchema = new mongoose.Schema({
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, required: true },
  dateOfBirth: { type: String, required: true }, // Changed to String to match form data
  address: { type: String, required: true },
  city: { type: String, required: true },
  state: { type: String, required: true },
  zipCode: { type: String, required: true },
  selectedPlan: { type: String, required: true },
  enrollmentDate: { type: Date, default: Date.now },
  status: { type: String, default: 'pending' }
});

const Member = mongoose.model('Member', memberSchema);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    mongodb: isMongoConnected ? 'connected' : 'disconnected'
  });
});

// Routes
app.post('/api/enrollments', async (req, res) => {
  try {
    if (!isMongoConnected) {
      return res.status(503).json({
        message: 'Database is not available. Please try again later.',
        details: 'MongoDB connection is not established'
      });
    }

    console.log('=== Processing Enrollment Request ===');
    console.log('Request Body:', JSON.stringify(req.body, null, 2));
    
    // Validate required fields
    const requiredFields = ['firstName', 'lastName', 'email', 'phone', 'dateOfBirth', 'address', 'city', 'state', 'zipCode', 'selectedPlan'];
    const missingFields = requiredFields.filter(field => {
      const value = req.body[field];
      const isMissing = !value || value.trim() === '';
      if (isMissing) {
        console.log(`Missing or empty field: ${field}`);
      }
      return isMissing;
    });
    
    if (missingFields.length > 0) {
      console.log('Missing fields:', missingFields);
      return res.status(400).json({ 
        message: 'Missing required fields', 
        fields: missingFields 
      });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(req.body.email)) {
      console.log('Invalid email format:', req.body.email);
      return res.status(400).json({ 
        message: 'Invalid email format' 
      });
    }

    // Validate phone format (10 digits)
    const phoneRegex = /^\d{10}$/;
    const cleanPhone = req.body.phone.replace(/\D/g, '');
    if (!phoneRegex.test(cleanPhone)) {
      console.log('Invalid phone format:', req.body.phone);
      return res.status(400).json({ 
        message: 'Phone number must be 10 digits' 
      });
    }

    // Check if email already exists
    const existingMember = await Member.findOne({ email: req.body.email });
    if (existingMember) {
      console.log('Email already exists:', req.body.email);
      return res.status(400).json({ 
        message: 'Email already registered' 
      });
    }

    // Create new member with the request data
    const memberData = {
      ...req.body,
      phone: cleanPhone,
      enrollmentDate: new Date()
    };

    console.log('Creating new member with data:', JSON.stringify(memberData, null, 2));
    const member = new Member(memberData);
    await member.save();
    console.log('Enrollment saved successfully:', member);
    res.status(201).json(member);
  } catch (error) {
    console.error('Error saving enrollment:', error);
    res.status(400).json({ 
      message: error.message,
      details: error.errors || error
    });
  }
});

app.get('/api/enrollments', async (req, res) => {
  try {
    const members = await Member.find().sort({ enrollmentDate: -1 });
    console.log(`Retrieved ${members.length} enrollments`);
    res.json(members);
  } catch (error) {
    console.error('Error fetching enrollments:', error);
    res.status(500).json({ 
      message: 'Error fetching enrollments',
      details: error.message 
    });
  }
});

app.get('/api/enrollments/:id', async (req, res) => {
  try {
    const member = await Member.findById(req.params.id);
    if (!member) {
      console.error('Member not found:', req.params.id);
      return res.status(404).json({ message: 'Member not found' });
    }
    console.log('Retrieved member:', member);
    res.json(member);
  } catch (error) {
    console.error('Error fetching member:', error);
    res.status(500).json({ 
      message: 'Error fetching member',
      details: error.message 
    });
  }
});

// Admin route to view enrollments in browser
app.get('/admin/enrollments', async (req, res) => {
  try {
    const members = await Member.find().sort({ enrollmentDate: -1 });
    res.send(`
      <html>
        <head>
          <title>Enrollment Records</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            tr:nth-child(even) { background-color: #f9f9f9; }
          </style>
        </head>
        <body>
          <h1>Enrollment Records</h1>
          <table>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Plan</th>
              <th>Status</th>
              <th>Enrollment Date</th>
            </tr>
            ${members.map(member => `
              <tr>
                <td>${member.firstName} ${member.lastName}</td>
                <td>${member.email}</td>
                <td>${member.phone}</td>
                <td>${member.selectedPlan}</td>
                <td>${member.status}</td>
                <td>${new Date(member.enrollmentDate).toLocaleString()}</td>
              </tr>
            `).join('')}
          </table>
        </body>
      </html>
    `);
  } catch (error) {
    console.error('Error rendering admin page:', error);
    res.status(500).send(`Error: ${error.message}`);
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
}); 