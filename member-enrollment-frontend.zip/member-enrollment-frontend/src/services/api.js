const API_URL = 'http://localhost:5000/api';

// Check if the server is available
export const checkServerHealth = async () => {
  try {
    const response = await fetch(`${API_URL}/health`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Server health check failed:', error);
    return { status: 'error', mongodb: 'unknown' };
  }
};

export const submitEnrollment = async (enrollmentData) => {
  try {
    // First check server health
    const health = await checkServerHealth();
    if (health.status !== 'ok') {
      throw new Error('Server is not available. Please try again later.');
    }
    if (health.mongodb !== 'connected') {
      throw new Error('Database is not available. Please try again later.');
    }

    console.log('Submitting enrollment data:', enrollmentData);
    const response = await fetch(`${API_URL}/enrollments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(enrollmentData),
    });

    const data = await response.json();
    
    if (!response.ok) {
      console.error('Server response:', data);
      throw new Error(data.message || 'Failed to submit enrollment');
    }

    console.log('Enrollment submitted successfully:', data);
    return data;
  } catch (error) {
    console.error('Error submitting enrollment:', error);
    throw error;
  }
};

export const getEnrollments = async () => {
  try {
    const response = await fetch(`${API_URL}/enrollments`);
    const data = await response.json();
    
    if (!response.ok) {
      console.error('Server response:', data);
      throw new Error(data.message || 'Failed to fetch enrollments');
    }
    
    return data;
  } catch (error) {
    console.error('Error fetching enrollments:', error);
    throw error;
  }
};

export const getEnrollmentById = async (id) => {
  try {
    const response = await fetch(`${API_URL}/enrollments/${id}`);
    const data = await response.json();
    
    if (!response.ok) {
      console.error('Server response:', data);
      throw new Error(data.message || 'Failed to fetch enrollment');
    }
    
    return data;
  } catch (error) {
    console.error('Error fetching enrollment:', error);
    throw error;
  }
}; 