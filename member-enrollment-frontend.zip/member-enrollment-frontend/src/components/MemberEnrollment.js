import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import './MemberEnrollment.css';
import PlanDetails from './PlanDetails';
import ReviewEnrollment from './ReviewEnrollment';
import Stepper from './Stepper';
import { plans } from '../data/plans';
import { submitEnrollment } from '../services/api';

const MemberEnrollment = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    selectedPlan: 'basic'
  });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState({ type: '', message: '' });

  useEffect(() => {
    const savedData = localStorage.getItem('enrollmentData');
    if (savedData) {
      setFormData(JSON.parse(savedData));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('enrollmentData', JSON.stringify(formData));
  }, [formData]);

  const validateForm = () => {
    const newErrors = {};
    const requiredFields = ['firstName', 'lastName', 'email', 'phone', 'dateOfBirth', 'address', 'city', 'state', 'zipCode'];
    
    requiredFields.forEach(field => {
      if (!formData[field]) {
        newErrors[field] = `${field.charAt(0).toUpperCase() + field.slice(1)} is required`;
      }
    });

    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (formData.phone && !/^\d{10}$/.test(formData.phone.replace(/\D/g, ''))) {
      newErrors.phone = 'Please enter a valid 10-digit phone number';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handlePlanSelect = (planId) => {
    setFormData(prev => ({
      ...prev,
      selectedPlan: planId
    }));
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      setStatus({ type: 'error', message: 'Please fill in all required fields correctly' });
      return;
    }

    try {
      setStatus({ type: 'info', message: 'Submitting enrollment...' });
      
      // Format the data before sending
      const enrollmentData = {
        firstName: formData.firstName.trim(),
        lastName: formData.lastName.trim(),
        email: formData.email.trim().toLowerCase(),
        phone: formData.phone.replace(/\D/g, ''), // Remove non-digits
        dateOfBirth: formData.dateOfBirth,
        address: formData.address.trim(),
        city: formData.city.trim(),
        state: formData.state.trim(),
        zipCode: formData.zipCode.trim(),
        selectedPlan: formData.selectedPlan
      };

      console.log('Submitting enrollment data:', enrollmentData);
      const response = await submitEnrollment(enrollmentData);
      console.log('Enrollment response:', response);
      
      setStatus({ type: 'success', message: 'Enrollment submitted successfully!' });
      localStorage.removeItem('enrollmentData');
      setTimeout(() => {
        navigate('/');
      }, 2000);
    } catch (error) {
      console.error('Enrollment error:', error);
      let errorMessage = 'Failed to submit enrollment. ';
      
      if (error.message.includes('Server is not available')) {
        errorMessage = 'The server is not available. Please try again later.';
      } else if (error.message.includes('Database is not available')) {
        errorMessage = 'The database is not available. Please try again later.';
      } else if (error.message.includes('Failed to fetch')) {
        errorMessage = 'Cannot connect to the server. Please check your internet connection and try again.';
      } else {
        errorMessage += error.message || 'Please try again.';
      }
      
      setStatus({ 
        type: 'error', 
        message: errorMessage
      });
    }
  };

  const handleNext = () => {
    if (currentStep === 1 && !validateForm()) {
      setStatus({ type: 'error', message: 'Please fill in all required fields correctly' });
      return;
    }
    setCurrentStep(prev => prev + 1);
    setStatus({ type: '', message: '' });
  };

  const handlePrev = () => {
    setCurrentStep(prev => prev - 1);
    setStatus({ type: '', message: '' });
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="enrollment-form">
            <h2>Personal Information</h2>
            <div className="form-group">
              <label htmlFor="firstName">First Name*</label>
              <input
                type="text"
                id="firstName"
                name="firstName"
                value={formData.firstName}
                onChange={handleInputChange}
                className={errors.firstName ? 'error' : ''}
              />
              {errors.firstName && <span className="error-message">{errors.firstName}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="lastName">Last Name*</label>
              <input
                type="text"
                id="lastName"
                name="lastName"
                value={formData.lastName}
                onChange={handleInputChange}
                className={errors.lastName ? 'error' : ''}
              />
              {errors.lastName && <span className="error-message">{errors.lastName}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="email">Email*</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className={errors.email ? 'error' : ''}
              />
              {errors.email && <span className="error-message">{errors.email}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="phone">Phone*</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                className={errors.phone ? 'error' : ''}
              />
              {errors.phone && <span className="error-message">{errors.phone}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="dateOfBirth">Date of Birth*</label>
              <input
                type="date"
                id="dateOfBirth"
                name="dateOfBirth"
                value={formData.dateOfBirth}
                onChange={handleInputChange}
                className={errors.dateOfBirth ? 'error' : ''}
              />
              {errors.dateOfBirth && <span className="error-message">{errors.dateOfBirth}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="address">Address*</label>
              <input
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                className={errors.address ? 'error' : ''}
              />
              {errors.address && <span className="error-message">{errors.address}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="city">City*</label>
              <input
                type="text"
                id="city"
                name="city"
                value={formData.city}
                onChange={handleInputChange}
                className={errors.city ? 'error' : ''}
              />
              {errors.city && <span className="error-message">{errors.city}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="state">State*</label>
              <input
                type="text"
                id="state"
                name="state"
                value={formData.state}
                onChange={handleInputChange}
                className={errors.state ? 'error' : ''}
              />
              {errors.state && <span className="error-message">{errors.state}</span>}
            </div>
            <div className="form-group">
              <label htmlFor="zipCode">ZIP Code*</label>
              <input
                type="text"
                id="zipCode"
                name="zipCode"
                value={formData.zipCode}
                onChange={handleInputChange}
                className={errors.zipCode ? 'error' : ''}
              />
              {errors.zipCode && <span className="error-message">{errors.zipCode}</span>}
            </div>
            <div className="form-buttons">
              <button className="next-step-btn" onClick={handleNext}>Next</button>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="plans-container">
            <h3>Select Your Plan</h3>
            <div className="plans-grid">
              {plans.map(plan => (
                <PlanDetails
                  key={plan.id}
                  plan={plan}
                  isSelected={formData.selectedPlan === plan.id}
                  onSelect={() => handlePlanSelect(plan.id)}
                />
              ))}
            </div>
            <div className="form-buttons">
              <button className="prev-step-btn" onClick={handlePrev}>Previous</button>
              <button className="next-step-btn" onClick={handleNext}>Next</button>
            </div>
          </div>
        );
      case 3:
        return (
          <div className="review-container">
            <h3>Review Your Information</h3>
            <ReviewEnrollment 
              formData={formData} 
              selectedPlan={plans.find(p => p.id === formData.selectedPlan)} 
            />
            <div className="form-buttons">
              <button className="prev-step-btn" onClick={handlePrev}>Previous</button>
              <button className="submit-btn" onClick={handleSubmit}>Submit Enrollment</button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="enrollment-container">
      <Stepper currentStep={currentStep} />
      {status.message && (
        <div className={`status-message ${status.type}`}>
          {status.message}
        </div>
      )}
      {renderStep()}
    </div>
  );
};

export default MemberEnrollment; 