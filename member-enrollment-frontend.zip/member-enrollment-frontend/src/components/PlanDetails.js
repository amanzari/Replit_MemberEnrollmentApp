import React from 'react';
import './PlanDetails.css';

const PlanDetails = ({ plan, onSelect, selected }) => {
  if (!plan) return null;

  const handleSelect = () => {
    // Convert plan name to lowercase and remove spaces for the ID
    const planId = plan.name.toLowerCase().replace(/\s+/g, '');
    onSelect(planId);
  };

  return (
    <div 
      className={`plan-card ${selected ? 'selected' : ''}`} 
      onClick={handleSelect}
      role="button"
      tabIndex={0}
      onKeyPress={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          handleSelect();
        }
      }}
    >
      <div className="plan-header">
        <h3>{plan.name}</h3>
        {selected && <span className="selected-badge">Selected</span>}
      </div>
      <div className="plan-price">
        <span className="price">${plan.monthlyPremium}</span>
        <span className="period">/month</span>
      </div>
      <div className="plan-deductible">
        Annual Deductible: ${plan.annualDeductible}
      </div>
      <p className="plan-description">{plan.description}</p>
      <div className="coverage-details">
        <h4>Coverage Includes:</h4>
        <ul>
          {Object.entries(plan.coverage).map(([key, value]) => (
            <li key={key}>
              <span className="coverage-item">{key}:</span>
              <span className="coverage-value">{value}</span>
            </li>
          ))}
        </ul>
      </div>
      <button 
        className={`select-plan-btn ${selected ? 'selected' : ''}`}
        onClick={(e) => {
          e.stopPropagation();
          handleSelect();
        }}
      >
        {selected ? 'Selected' : 'Select Plan'}
      </button>
    </div>
  );
};

export default PlanDetails; 