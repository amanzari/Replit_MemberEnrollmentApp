import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
  const location = useLocation();

  return (
    <nav className="navbar">
      <Link to="/" className="navbar-brand">
        <i className="fas fa-shield-alt"></i>
        HealthShield
      </Link>
      <ul className="nav-links">
        <li>
          <Link to="/" className={location.pathname === '/' ? 'active' : ''}>
            <i className="fas fa-user-plus"></i>
            <span className="nav-label">Personal Info</span>
          </Link>
        </li>
        <li>
          <Link to="/plans" className={location.pathname === '/plans' ? 'active' : ''}>
            <i className="fas fa-clipboard-list"></i>
            <span className="nav-label">Select Plan</span>
          </Link>
        </li>
        <li>
          <Link to="/review" className={location.pathname === '/review' ? 'active' : ''}>
            <i className="fas fa-check-circle"></i>
            <span className="nav-label">Review</span>
          </Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar; 