import React, { useState } from 'react';
import './EnrollmentStepper.css';

const EnrollmentStepper = ({ steps, currentStep, onStepClick }) => {
  return (
    <div className="stepper-container">
      {steps.map((step, index) => (
        <div
          key={step.id}
          className={`stepper-step ${index + 1 === currentStep ? 'active' : ''} ${
            index + 1 < currentStep ? 'completed' : ''
          }`}
          onClick={() => index + 1 < currentStep && onStepClick(index + 1)}
        >
          <div className="step-number">{index + 1}</div>
          <div className="step-label">{step.label}</div>
        </div>
      ))}
    </div>
  );
};

export default EnrollmentStepper; 