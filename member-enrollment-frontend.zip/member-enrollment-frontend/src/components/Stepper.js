import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './Stepper.css';

const Stepper = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const steps = [
    { path: '/', label: 'Personal Info', icon: 'fa-user-plus' },
    { path: '/plans', label: 'Select Plan', icon: 'fa-clipboard-list' },
    { path: '/review', label: 'Review', icon: 'fa-check-circle' },
    { path: '/submit', label: 'Submit', icon: 'fa-paper-plane' }
  ];

  const getCurrentStep = () => {
    return steps.findIndex(step => step.path === location.pathname);
  };

  const currentStep = getCurrentStep();

  const handleStepClick = (index) => {
    if (index < currentStep) {
      navigate(steps[index].path);
    }
  };

  return (
    <div className="stepper-container">
      <div className="stepper">
        {steps.map((step, index) => (
          <div key={step.path} className="step-wrapper">
            <div 
              className={`step ${index === currentStep ? 'active' : ''} ${index < currentStep ? 'completed' : ''}`}
              onClick={() => handleStepClick(index)}
            >
              <i className={`fas ${step.icon}`}></i>
              <span className="step-label">{step.label}</span>
            </div>
            {index < steps.length - 1 && (
              <div className={`step-connector ${index < currentStep ? 'active' : ''}`}></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Stepper; 