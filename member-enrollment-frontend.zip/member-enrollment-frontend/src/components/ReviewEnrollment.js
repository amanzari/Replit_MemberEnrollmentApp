import React from 'react';
import './ReviewEnrollment.css';

const ReviewEnrollment = ({ formData, selectedPlan, onEdit }) => {
  if (!formData || !selectedPlan) return null;

  return (
    <div className="review-container">
      <div className="review-section">
        <div className="review-header">
          <h4>Personal Information</h4>
          <button onClick={() => onEdit('personal')} className="edit-btn">
            Edit
          </button>
        </div>
        <div className="review-grid">
          <div className="review-item">
            <span className="review-label">Name:</span>
            <span className="review-value">{`${formData.firstName} ${formData.lastName}`}</span>
          </div>
          <div className="review-item">
            <span className="review-label">Email:</span>
            <span className="review-value">{formData.email}</span>
          </div>
          <div className="review-item">
            <span className="review-label">Phone:</span>
            <span className="review-value">{formData.phone}</span>
          </div>
          <div className="review-item">
            <span className="review-label">Date of Birth:</span>
            <span className="review-value">{formData.dateOfBirth}</span>
          </div>
          <div className="review-item">
            <span className="review-label">Address:</span>
            <span className="review-value">{formData.address}</span>
          </div>
          <div className="review-item">
            <span className="review-label">City:</span>
            <span className="review-value">{formData.city}</span>
          </div>
          <div className="review-item">
            <span className="review-label">State:</span>
            <span className="review-value">{formData.state}</span>
          </div>
          <div className="review-item">
            <span className="review-label">ZIP Code:</span>
            <span className="review-value">{formData.zipCode}</span>
          </div>
        </div>
      </div>

      <div className="review-section">
        <div className="review-header">
          <h4>Selected Plan</h4>
          <button onClick={() => onEdit('plan')} className="edit-btn">
            Edit
          </button>
        </div>
        <div className="plan-summary">
          <h5>{selectedPlan.name}</h5>
          <div className="plan-details">
            <div className="detail-item">
              <span className="detail-label">Monthly Premium:</span>
              <span className="detail-value">${selectedPlan.monthlyPremium}/month</span>
            </div>
            <div className="detail-item">
              <span className="detail-label">Annual Deductible:</span>
              <span className="detail-value">${selectedPlan.annualDeductible}</span>
            </div>
          </div>
          <div className="coverage-summary">
            <h6>Coverage Details:</h6>
            <ul>
              {Object.entries(selectedPlan.coverage).map(([key, value]) => (
                <li key={key}>
                  <span className="coverage-label">{key}:</span>
                  <span className="coverage-value">{value}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReviewEnrollment; 