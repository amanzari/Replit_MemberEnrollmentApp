import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import MemberEnrollment from './components/MemberEnrollment';
import Navbar from './components/Navbar';

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <header className="App-header">
          <h1>Insurance Member Enrollment</h1>
        </header>
        <main>
          <Routes>
            <Route path="/" element={<MemberEnrollment />} />
            <Route path="/plans" element={<MemberEnrollment />} />
            <Route path="/review" element={<MemberEnrollment />} />
            <Route path="/submit" element={<MemberEnrollment />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
