export const plans = [
  {
    id: 'basic',
    name: 'Basic Plan',
    monthlyPremium: 99,
    annualDeductible: 2000,
    description: 'Essential coverage for basic healthcare needs',
    coverage: {
      'Primary Care': '3 visits/year',
      'Specialist Care': '2 visits/year',
      'Emergency Room': 'Covered after deductible',
      'Hospitalization': '80% after deductible',
      'Prescription Drugs': 'Generic only',
      'Preventive Care': 'Fully covered',
      'Dental': 'Not included',
      'Vision': 'Not included'
    }
  },
  {
    id: 'standard',
    name: 'Standard Plan',
    monthlyPremium: 149,
    annualDeductible: 1500,
    description: 'Comprehensive coverage for individuals and families',
    coverage: {
      'Primary Care': '6 visits/year',
      'Specialist Care': '4 visits/year',
      'Emergency Room': 'Covered after deductible',
      'Hospitalization': '90% after deductible',
      'Prescription Drugs': 'Generic and brand name',
      'Preventive Care': 'Fully covered',
      'Dental': 'Basic coverage',
      'Vision': 'Basic coverage'
    }
  },
  {
    id: 'premium',
    name: 'Premium Plan',
    monthlyPremium: 249,
    annualDeductible: 1000,
    description: 'Premium coverage with extensive benefits',
    coverage: {
      'Primary Care': 'Unlimited visits',
      'Specialist Care': 'Unlimited visits',
      'Emergency Room': 'Fully covered',
      'Hospitalization': 'Fully covered',
      'Prescription Drugs': 'All medications covered',
      'Preventive Care': 'Fully covered',
      'Dental': 'Comprehensive coverage',
      'Vision': 'Comprehensive coverage'
    }
  }
]; 