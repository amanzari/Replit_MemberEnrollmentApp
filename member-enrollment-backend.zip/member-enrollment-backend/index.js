const express = require('express');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Insurance plan details
const insurancePlans = {
  basic: {
    name: 'Basic Plan',
    monthlyPremium: 99.99,
    annualDeductible: 2000,
    coverage: {
      doctorVisits: '3 visits per year',
      prescriptionDrugs: 'Generic only',
      hospitalization: '80% coverage',
      emergencyRoom: '80% coverage',
      preventiveCare: 'Fully covered',
      dental: 'Not included',
      vision: 'Not included'
    },
    description: 'Essential coverage for basic healthcare needs. Perfect for individuals who are generally healthy and need minimal medical attention.'
  },
  standard: {
    name: 'Standard Plan',
    monthlyPremium: 149.99,
    annualDeductible: 1000,
    coverage: {
      doctorVisits: 'Unlimited visits',
      prescriptionDrugs: 'Generic and brand name',
      hospitalization: '90% coverage',
      emergencyRoom: '90% coverage',
      preventiveCare: 'Fully covered',
      dental: 'Basic coverage',
      vision: 'Basic coverage'
    },
    description: 'Comprehensive coverage for individuals and families. Includes additional benefits like dental and vision care.'
  },
  premium: {
    name: 'Premium Plan',
    monthlyPremium: 249.99,
    annualDeductible: 500,
    coverage: {
      doctorVisits: 'Unlimited visits',
      prescriptionDrugs: 'All medications covered',
      hospitalization: '100% coverage',
      emergencyRoom: '100% coverage',
      preventiveCare: 'Fully covered',
      dental: 'Comprehensive coverage',
      vision: 'Comprehensive coverage',
      alternativeMedicine: 'Covered up to $1000/year'
    },
    description: 'Premium coverage with the lowest out-of-pocket costs. Ideal for those who want maximum coverage and flexibility in their healthcare choices.'
  }
};

// In-memory storage for enrolled members
const enrolledMembers = [];

// Basic route
app.get('/', (req, res) => {
  res.json({ message: 'Welcome to the Member Enrollment Backend API' });
});

// Get insurance plans
app.get('/api/plans', (req, res) => {
  res.json(insurancePlans);
});

// Enrollment endpoint
app.post('/api/enroll', (req, res) => {
  try {
    const memberData = req.body;
    
    // Basic validation
    const requiredFields = [
      'firstName', 'lastName', 'email', 'phone',
      'dateOfBirth', 'address', 'city', 'state',
      'zipCode', 'insurancePlan'
    ];

    const missingFields = requiredFields.filter(field => !memberData[field]);
    
    if (missingFields.length > 0) {
      return res.status(400).json({
        success: false,
        message: `Missing required fields: ${missingFields.join(', ')}`
      });
    }

    // Validate insurance plan
    if (!insurancePlans[memberData.insurancePlan]) {
      return res.status(400).json({
        success: false,
        message: 'Invalid insurance plan selected'
      });
    }

    // Generate a unique member ID
    const memberId = `MEM${Date.now()}`;
    
    // Add member to storage with plan details
    const newMember = {
      memberId,
      ...memberData,
      enrollmentDate: new Date().toISOString(),
      planDetails: insurancePlans[memberData.insurancePlan]
    };
    
    enrolledMembers.push(newMember);

    // Return success response with plan details
    res.status(201).json({
      success: true,
      message: 'Member enrolled successfully',
      memberId,
      planDetails: insurancePlans[memberData.insurancePlan]
    });
  } catch (error) {
    console.error('Enrollment error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to process enrollment'
    });
  }
});

// Get all enrolled members
app.get('/api/members', (req, res) => {
  res.json(enrolledMembers);
});

// Start server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
}); 