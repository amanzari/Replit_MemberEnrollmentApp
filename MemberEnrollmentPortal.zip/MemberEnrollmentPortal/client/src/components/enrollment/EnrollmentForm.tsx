import { useState, useEffect } from "react";
import { useForm, FormProvider } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { enrollmentFormSchema, personalInfoSchema } from "@shared/schema";
import { z } from "zod";
import { Card } from "@/components/ui/card";
import { useMultiStepForm } from "@/lib/hooks/useMultiStepForm";
import StepIndicator from "./StepIndicator";
import StepOne from "./StepOne";
import StepTwo from "./StepTwo";
import StepThree from "./StepThree";
import StepFour from "./StepFour";
import SuccessMessage from "./SuccessMessage";
import { InsurancePlan } from "@/lib/insurance-plans";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type FormValues = z.infer<typeof enrollmentFormSchema>;

export default function EnrollmentForm() {
  const [selectedPlan, setSelectedPlan] = useState<InsurancePlan | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [enrollmentData, setEnrollmentData] = useState<any>(null);
  const { toast } = useToast();

  // Initialize form with all fields
  const methods = useForm<FormValues>({
    resolver: zodResolver(enrollmentFormSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      dateOfBirth: "",
      gender: "",
      email: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      planId: "",
      height: 60, // Default value in inches (5ft)
      weight: 150, // Default value in pounds
      hasPreExistingConditions: false,
      usesTobacco: false,
      beneficiaryName: "",
      beneficiaryRelationship: "",
      beneficiaryPhone: "",
      beneficiaryEmail: "",
    },
    // Don't validate all fields on every change
    mode: "onSubmit"
  });

  const enrollmentMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest("POST", "/api/enrollments", {
        ...data,
        hasPreExistingConditions: !!data.hasPreExistingConditions,
        usesTobacco: !!data.usesTobacco,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setEnrollmentData(data);
      setIsSuccess(true);
      methods.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit enrollment",
        variant: "destructive",
      });
    }
  });

  const { currentStep, steps, currentStepIndex, goTo, next, back, isFirstStep, isLastStep } = useMultiStepForm([
    { id: "personal-info", title: "Personal Info", component: <StepOne /> },
    { 
      id: "plan-selection", 
      title: "Plan Selection", 
      component: <StepTwo 
        selectedPlan={selectedPlan} 
        onSelectPlan={(plan) => {
          setSelectedPlan(plan);
          methods.setValue("planId", plan.id);
        }} 
      /> 
    },
    { id: "additional-details", title: "Additional Details", component: <StepThree /> },
    { id: "review", title: "Review & Submit", component: <StepFour selectedPlan={selectedPlan} /> }
  ]);

  const handleNext = () => {
    // For the first step, validate only the personal info fields
    if (currentStepIndex === 0) {
      const personalInfoData = methods.getValues();
      
      // Check if required fields are filled
      const requiredFields = [
        'firstName', 'lastName', 'dateOfBirth', 'gender', 
        'email', 'phone', 'address', 'city', 'state', 'zipCode'
      ];
      
      // Simple validation for personal info
      let hasEmptyFields = false;
      requiredFields.forEach(field => {
        if (!personalInfoData[field]) {
          hasEmptyFields = true;
          methods.setError(field as any, {
            type: 'required',
            message: 'This field is required'
          });
        }
      });
      
      if (hasEmptyFields) {
        toast({
          title: "Missing information",
          description: "Please fill out all required fields",
          variant: "destructive",
        });
        return;
      }
      
      // If all personal info fields are valid, proceed to next step
      next();
      return;
    }
      
    // For the plan selection step
    if (currentStepIndex === 1) {
      if (!selectedPlan) {
        toast({
          title: "Please select a plan",
          description: "You must select an insurance plan to continue",
          variant: "destructive",
        });
        return;
      }
      
      // Proceed to next step
      next();
      return;
    }
    
    // For all other steps
    next();
  };
  
  const onSubmit = async (data: FormValues) => {
    console.log("Form submitted with data:", data);
    
    if (!isLastStep) {
      handleNext();
    } else {
      // Submit the form data
      enrollmentMutation.mutate(data);
    }
  };

  if (isSuccess && enrollmentData) {
    return <SuccessMessage email={enrollmentData.email} coverageDate={enrollmentData.coverageStartDate} />;
  }

  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)}>
        <StepIndicator 
          currentStep={currentStepIndex + 1}
          steps={steps.map(step => step.title)}
        />
        
        <Card className="bg-white shadow-md rounded-lg overflow-hidden mb-8">
          <div className="p-6 bg-primary text-white">
            <h3 className="text-xl font-semibold">{currentStep.title}</h3>
            <p className="text-blue-100">
              {currentStepIndex === 0 && "Tell us about yourself to get started."}
              {currentStepIndex === 1 && "Choose the coverage that best fits your needs."}
              {currentStepIndex === 2 && "Please provide medical history and beneficiary information."}
              {currentStepIndex === 3 && "Please review your information before submitting."}
            </p>
          </div>
          
          <div className="p-6">
            {currentStep.component}
          </div>
          
          <div className="p-6 bg-gray-100 flex justify-between">
            {!isFirstStep ? (
              <button 
                type="button" 
                onClick={back}
                className="px-5 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-200 transition"
              >
                Back
              </button>
            ) : (
              <div></div> // Empty div to maintain flex spacing
            )}
            
            <button 
              type="submit"
              disabled={enrollmentMutation.isPending}
              className={`px-5 py-2 ${isLastStep ? 'bg-green-600' : 'bg-primary'} text-white rounded-md hover:opacity-90 transition flex items-center ${enrollmentMutation.isPending ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {enrollmentMutation.isPending ? (
                <>Processing...</>
              ) : isLastStep ? (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  Submit Enrollment
                </>
              ) : (
                `Next: ${steps[currentStepIndex + 1]?.title || ""}`
              )}
            </button>
          </div>
        </Card>
      </form>
    </FormProvider>
  );
}
