import { useFormContext } from "react-hook-form";
import { useState, useEffect } from "react";
import { z } from "zod";
import { medicalAndBeneficiarySchema } from "@shared/schema";
import {
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
  FormDescription
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

type MedicalBeneficiaryValues = z.infer<typeof medicalAndBeneficiarySchema>;

export default function StepThree() {
  const { control, watch, setValue } = useFormContext<MedicalBeneficiaryValues>();
  const [showConditions, setShowConditions] = useState(false);
  
  const hasPreExistingConditions = watch("hasPreExistingConditions");
  
  // Update the visibility of the conditions textarea when the radio changes
  useEffect(() => {
    setShowConditions(hasPreExistingConditions);
  }, [hasPreExistingConditions]);
  
  return (
    <div>
      <h4 className="text-gray-800 font-medium mb-4">Medical History</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <FormField
          control={control}
          name="hasPreExistingConditions"
          render={({ field }) => (
            <FormItem className="md:col-span-2">
              <FormLabel>Do you have any pre-existing medical conditions?<span className="text-red-500 ml-1">*</span></FormLabel>
              <FormControl>
                <RadioGroup
                  onValueChange={(value) => {
                    setValue("hasPreExistingConditions", value === "yes");
                    if (value === "no") {
                      setValue("preExistingConditions", "");
                    }
                  }}
                  defaultValue={field.value ? "yes" : "no"}
                  className="flex space-x-6"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="yes-conditions" />
                    <Label htmlFor="yes-conditions">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="no-conditions" />
                    <Label htmlFor="no-conditions">No</Label>
                  </div>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {showConditions && (
          <FormField
            control={control}
            name="preExistingConditions"
            render={({ field }) => (
              <FormItem className="md:col-span-2">
                <FormLabel>Please specify your conditions<span className="text-red-500 ml-1">*</span></FormLabel>
                <FormControl>
                  <Textarea 
                    {...field} 
                    rows={3} 
                    placeholder="Please describe your pre-existing conditions"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
        
        <FormField
          control={control}
          name="height"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Height (in inches)<span className="text-red-500 ml-1">*</span></FormLabel>
              <FormControl>
                <Input type="number" {...field} placeholder="70" />
              </FormControl>
              <FormDescription>Example: 5'10" = 70 inches</FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={control}
          name="weight"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Weight (in pounds)<span className="text-red-500 ml-1">*</span></FormLabel>
              <FormControl>
                <Input type="number" {...field} placeholder="180" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={control}
          name="usesTobacco"
          render={({ field }) => (
            <FormItem className="md:col-span-2">
              <FormLabel>Do you smoke or use tobacco products?<span className="text-red-500 ml-1">*</span></FormLabel>
              <FormControl>
                <RadioGroup
                  onValueChange={(value) => setValue("usesTobacco", value === "yes")}
                  defaultValue={field.value ? "yes" : "no"}
                  className="flex space-x-6"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="yes" id="yes-tobacco" />
                    <Label htmlFor="yes-tobacco">Yes</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="no" id="no-tobacco" />
                    <Label htmlFor="no-tobacco">No</Label>
                  </div>
                </RadioGroup>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
      
      <h4 className="text-gray-800 font-medium mb-4">Beneficiary Information</h4>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <FormField
          control={control}
          name="beneficiaryName"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Beneficiary Full Name<span className="text-red-500 ml-1">*</span></FormLabel>
              <FormControl>
                <Input {...field} placeholder="Full name of your beneficiary" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={control}
          name="beneficiaryRelationship"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Relationship<span className="text-red-500 ml-1">*</span></FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select relationship" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="spouse">Spouse</SelectItem>
                  <SelectItem value="child">Child</SelectItem>
                  <SelectItem value="parent">Parent</SelectItem>
                  <SelectItem value="sibling">Sibling</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={control}
          name="beneficiaryPhone"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Beneficiary Phone Number<span className="text-red-500 ml-1">*</span></FormLabel>
              <FormControl>
                <Input {...field} placeholder="(555) 123-4567" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={control}
          name="beneficiaryEmail"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Beneficiary Email (Optional)</FormLabel>
              <FormControl>
                <Input type="email" {...field} placeholder="beneficiary@email.com" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
    </div>
  );
}
