import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarIcon, Check, CheckCircle } from "lucide-react";
import { useEffect } from "react";
import { formatDate } from "@/lib/utils";

interface SuccessMessageProps {
  email: string;
  coverageDate: string;
}

export default function SuccessMessage({ email, coverageDate }: SuccessMessageProps) {
  // Create confetti animation on mount
  useEffect(() => {
    createConfetti();
  }, []);
  
  function createConfetti() {
    const colors = ['#1A56DB', '#3B82F6', '#10B981', '#FBBF24'];
    const confettiContainer = document.createElement('div');
    confettiContainer.style.position = 'fixed';
    confettiContainer.style.top = '0';
    confettiContainer.style.left = '0';
    confettiContainer.style.width = '100%';
    confettiContainer.style.height = '100%';
    confettiContainer.style.pointerEvents = 'none';
    confettiContainer.style.zIndex = '9999';
    document.body.appendChild(confettiContainer);
    
    for (let i = 0; i < 100; i++) {
      const confetti = document.createElement('div');
      confetti.classList.add('confetti');
      confetti.style.position = 'absolute';
      confetti.style.left = Math.random() * 100 + '%';
      confetti.style.width = Math.random() * 10 + 5 + 'px';
      confetti.style.height = Math.random() * 10 + 5 + 'px';
      confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
      confetti.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
      confetti.style.animationDelay = Math.random() * 3 + 's';
      
      confettiContainer.appendChild(confetti);
    }
    
    // Remove after animation completes
    setTimeout(() => {
      document.body.removeChild(confettiContainer);
    }, 7000);
  }
  
  const formattedDate = formatDate(coverageDate || "") || "processing";
  
  return (
    <Card className="text-center mt-10 bg-white shadow-md rounded-lg overflow-hidden">
      <div className="p-6 bg-green-600 text-white">
        <CheckCircle className="h-16 w-16 mx-auto" />
        <h3 className="text-2xl font-bold mt-2">Enrollment Submitted Successfully!</h3>
      </div>
      <div className="p-8">
        <p className="text-lg text-gray-700 mb-6">
          Thank you for enrolling with SecureHealth Insurance. We've sent a confirmation email to <span className="font-medium">{email}</span>.
        </p>
        <p className="text-gray-600 mb-8">
          Your application will be processed within 2-3 business days. You will receive your insurance card and welcome kit by mail within 7-10 business days.
        </p>
        
        <div className="text-center">
          <div className="inline-flex items-center justify-center text-gray-500 mb-6">
            <CalendarIcon className="h-5 w-5 mr-2" />
            <span>Your coverage will begin on <span className="font-medium">{formattedDate}</span></span>
          </div>
        </div>
        
        <div className="mt-8">
          <Button className="mr-4" onClick={() => window.location.href = "/"}>
            Back to Home
          </Button>
          <Button variant="outline" onClick={() => window.print()}>
            Print Confirmation
          </Button>
        </div>
      </div>
    </Card>
  );
}
