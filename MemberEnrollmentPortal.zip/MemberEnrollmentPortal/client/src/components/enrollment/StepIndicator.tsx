import * as React from "react";
import { cn } from "@/lib/utils";
import { CheckIcon } from "lucide-react";

interface StepIndicatorProps {
  currentStep: number;
  steps: string[];
}

export default function StepIndicator({ currentStep, steps }: StepIndicatorProps) {
  return (
    <div className="enrollment-stepper mb-8">
      <div className="flex justify-between items-center">
        {steps.map((step, index) => (
          <div key={index} className="flex items-center" style={{ width: index < steps.length - 1 ? 'auto' : 'auto' }}>
            <div className="flex flex-col items-center">
              <div 
                className={cn(
                  "w-10 h-10 rounded-full border-2 flex items-center justify-center mb-2",
                  currentStep > index + 1 ? "bg-green-600 border-green-600 text-white" : 
                  currentStep === index + 1 ? "bg-primary border-primary text-white" : 
                  "bg-white border-gray-300 text-gray-500"
                )}
              >
                {currentStep > index + 1 ? (
                  <CheckIcon className="h-5 w-5" />
                ) : (
                  index + 1
                )}
              </div>
              <span 
                className={cn(
                  "text-sm font-medium",
                  currentStep === index + 1 ? "text-gray-800" : "text-gray-500"
                )}
              >
                {step}
              </span>
            </div>
            
            {index < steps.length - 1 && (
              <div className="h-1 w-12 md:w-24 lg:w-32 bg-gray-200 mx-2">
                <div 
                  className="h-full bg-primary" 
                  style={{ 
                    width: currentStep > index + 1 ? "100%" : "0%" 
                  }}
                />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
