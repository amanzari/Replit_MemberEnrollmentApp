import { CheckCircle2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { InsurancePlan } from "@/lib/insurance-plans";

interface PlanCardProps {
  plan: InsurancePlan;
  isSelected: boolean;
  onSelect: () => void;
}

export default function PlanCard({ plan, isSelected, onSelect }: PlanCardProps) {
  return (
    <div 
      className={cn(
        "border rounded-lg p-5 cursor-pointer transition hover:shadow-lg",
        isSelected ? "border-primary border-2 bg-blue-50 plan-card selected" : ""
      )}
      data-plan-id={plan.id}
      onClick={onSelect}
    >
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center">
            <h5 className="text-lg font-semibold text-gray-800">{plan.name}</h5>
            {plan.isPopular && (
              <span className="ml-2 px-2 py-1 bg-primary-light text-white text-xs rounded-full">
                Most Popular
              </span>
            )}
          </div>
          <p className="text-gray-600 mt-1">{plan.description}</p>
          <ul className="mt-4 space-y-2">
            {plan.features.map((feature, index) => (
              <li key={index} className="flex items-center text-sm">
                <CheckCircle2 className="h-4 w-4 text-green-600 mr-2" />
                {feature}
              </li>
            ))}
            {plan.notIncluded?.map((feature, index) => (
              <li key={index} className="flex items-center text-sm text-gray-400">
                <XCircle className="h-4 w-4 text-gray-300 mr-2" />
                {feature}
              </li>
            ))}
          </ul>
        </div>
        <div className="text-right">
          <span className="block text-2xl font-bold text-primary">${plan.price}</span>
          <span className="text-gray-500 text-sm">per month</span>
        </div>
      </div>
      <div className="mt-5 pt-5 border-t">
        <div className="flex justify-between items-center">
          <div>
            <span className="text-sm text-gray-600">
              Annual Deductible: <strong>${plan.deductible.toLocaleString()}</strong>
            </span>
          </div>
          <Button
            variant={isSelected ? "default" : "outline"}
            className={cn(
              "select-plan-btn",
              isSelected ? "bg-primary text-white" : "border-primary text-primary hover:bg-primary/10"
            )}
            onClick={onSelect}
          >
            {isSelected ? "Selected" : "Select Plan"}
          </Button>
        </div>
      </div>
    </div>
  );
}
