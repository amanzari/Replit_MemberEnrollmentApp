import { useFormContext } from "react-hook-form";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { insurancePlans, InsurancePlan } from "@/lib/insurance-plans";
import PlanCard from "./PlanCard";

interface StepTwoProps {
  selectedPlan: InsurancePlan | null;
  onSelectPlan: (plan: InsurancePlan) => void;
}

export default function StepTwo({ selectedPlan, onSelectPlan }: StepTwoProps) {
  const { formState: { errors } } = useFormContext();
  
  return (
    <div>
      <div className="mb-6">
        <h4 className="text-gray-800 font-medium mb-4">Available Plans</h4>
        
        <div className="space-y-4">
          {insurancePlans.map((plan) => (
            <PlanCard 
              key={plan.id}
              plan={plan}
              isSelected={selectedPlan?.id === plan.id}
              onSelect={() => onSelectPlan(plan)}
            />
          ))}
        </div>
      </div>
      
      {errors.planId && (
        <Alert variant="destructive" className="mt-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Please select an insurance plan to continue.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
