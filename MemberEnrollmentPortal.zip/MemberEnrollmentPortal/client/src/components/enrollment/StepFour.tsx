import { useFormContext } from "react-hook-form";
import { z } from "zod";
import { enrollmentFormSchema } from "@shared/schema";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/utils";
import { InsurancePlan } from "@/lib/insurance-plans";
import { useState, useEffect } from "react";
import {
  FormField,
  FormItem,
  FormControl,
  FormMessage
} from "@/components/ui/form";
import { getRelationshipText } from "@/lib/validation";

type FormValues = z.infer<typeof enrollmentFormSchema>;

interface StepFourProps {
  selectedPlan: InsurancePlan | null;
}

export default function StepFour({ selectedPlan }: StepFourProps) {
  const { control, watch, formState: { errors } } = useFormContext<FormValues>();
  const [formData, setFormData] = useState<FormValues | null>(null);
  
  // Get current form values to display in the summary
  useEffect(() => {
    const subscription = watch((value) => {
      setFormData(value as FormValues);
    });
    
    return () => subscription.unsubscribe();
  }, [watch]);
  
  if (!formData) {
    return <div>Loading...</div>;
  }
  
  return (
    <div>
      <div className="mb-8">
        <h4 className="text-gray-800 font-medium mb-3 flex items-center">
          <span>Personal Information</span>
          <button 
            type="button" 
            className="ml-2 text-primary text-sm hover:underline"
            onClick={() => {
              // Find the closest form and dispatch an event with currentStep
              const form = document.querySelector('form');
              if (form) {
                const event = new CustomEvent('goto-step', { detail: { step: 0 } });
                form.dispatchEvent(event);
              }
            }}
          >
            Edit
          </button>
        </h4>
        <div className="bg-gray-100 p-4 rounded-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Full Name</p>
              <p className="font-medium">{`${formData.firstName} ${formData.lastName}`}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Date of Birth</p>
              <p className="font-medium">{formatDate(formData.dateOfBirth)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Email Address</p>
              <p className="font-medium">{formData.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Phone Number</p>
              <p className="font-medium">{formData.phone}</p>
            </div>
            <div className="md:col-span-2">
              <p className="text-sm text-gray-500">Address</p>
              <p className="font-medium">{`${formData.address}, ${formData.city}, ${formData.state} ${formData.zipCode}`}</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h4 className="text-gray-800 font-medium mb-3 flex items-center">
          <span>Selected Plan</span>
          <button 
            type="button" 
            className="ml-2 text-primary text-sm hover:underline"
            onClick={() => {
              const form = document.querySelector('form');
              if (form) {
                const event = new CustomEvent('goto-step', { detail: { step: 1 } });
                form.dispatchEvent(event);
              }
            }}
          >
            Edit
          </button>
        </h4>
        {selectedPlan ? (
          <div className="bg-gray-100 p-4 rounded-lg">
            <div className="flex justify-between">
              <div>
                <p className="text-sm text-gray-500">Plan Name</p>
                <p className="font-medium text-lg">{selectedPlan.name}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500">Monthly Premium</p>
                <p className="font-medium text-lg text-primary">{formatCurrency(selectedPlan.price)}</p>
              </div>
            </div>
            <div className="mt-3">
              <p className="text-sm text-gray-500">Deductible</p>
              <p className="font-medium">{formatCurrency(selectedPlan.deductible)} annually</p>
            </div>
          </div>
        ) : (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Please go back and select a plan
            </AlertDescription>
          </Alert>
        )}
      </div>
      
      <div className="mb-8">
        <h4 className="text-gray-800 font-medium mb-3 flex items-center">
          <span>Medical & Beneficiary Information</span>
          <button 
            type="button" 
            className="ml-2 text-primary text-sm hover:underline"
            onClick={() => {
              const form = document.querySelector('form');
              if (form) {
                const event = new CustomEvent('goto-step', { detail: { step: 2 } });
                form.dispatchEvent(event);
              }
            }}
          >
            Edit
          </button>
        </h4>
        <div className="bg-gray-100 p-4 rounded-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500">Height</p>
              <p className="font-medium">{formData.height} inches</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Weight</p>
              <p className="font-medium">{formData.weight} pounds</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Pre-existing Conditions</p>
              <p className="font-medium">{formData.hasPreExistingConditions ? "Yes" : "No"}</p>
              {formData.hasPreExistingConditions && formData.preExistingConditions && (
                <p className="text-sm mt-1">{formData.preExistingConditions}</p>
              )}
            </div>
            <div>
              <p className="text-sm text-gray-500">Tobacco Use</p>
              <p className="font-medium">{formData.usesTobacco ? "Yes" : "No"}</p>
            </div>
            <div className="md:col-span-2">
              <p className="text-sm text-gray-500">Beneficiary</p>
              <p className="font-medium">
                {formData.beneficiaryName} ({getRelationshipText(formData.beneficiaryRelationship)})
              </p>
              <p className="text-sm">{formData.beneficiaryPhone}</p>
              {formData.beneficiaryEmail && <p className="text-sm">{formData.beneficiaryEmail}</p>}
            </div>
          </div>
        </div>
      </div>
      
      <div className="mb-6">
        <FormField
          control={control}
          name="termsAccepted"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
              <FormControl>
                <Checkbox
                  checked={field.value}
                  onCheckedChange={field.onChange}
                  id="terms"
                />
              </FormControl>
              <div className="space-y-1 leading-none">
                <Label htmlFor="terms">
                  I agree to the <a href="#" className="text-primary hover:underline">Terms and Conditions</a> and <a href="#" className="text-primary hover:underline">Privacy Policy</a>.
                </Label>
                <FormMessage />
              </div>
            </FormItem>
          )}
        />
        
        {errors.termsAccepted && (
          <p className="text-destructive text-sm mt-2">You must agree to the terms to continue</p>
        )}
      </div>
    </div>
  );
}
