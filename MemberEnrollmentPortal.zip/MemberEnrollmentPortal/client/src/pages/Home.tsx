import Header from "@/components/Header";
import Footer from "@/components/Footer";
import EnrollmentForm from "@/components/enrollment/EnrollmentForm";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <main className="flex-grow max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8 w-full">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">Member Enrollment</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Complete the enrollment process to get covered with our comprehensive insurance plans.
          </p>
        </div>
        
        <EnrollmentForm />
      </main>
      <Footer />
    </div>
  );
}
