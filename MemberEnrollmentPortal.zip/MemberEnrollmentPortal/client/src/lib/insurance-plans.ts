export interface InsurancePlan {
  id: string;
  name: string;
  description: string;
  price: number;
  deductible: number;
  features: string[];
  notIncluded?: string[];
  isPopular?: boolean;
}

export const insurancePlans: InsurancePlan[] = [
  {
    id: "basic",
    name: "Basic Coverage",
    description: "Essential health coverage for individuals on a budget",
    price: 199,
    deductible: 2500,
    features: [
      "Primary care visits",
      "Emergency services",
      "Prescription coverage (generic only)"
    ],
    notIncluded: [
      "Specialist visits ($40 copay)",
      "Dental and vision"
    ]
  },
  {
    id: "standard",
    name: "Standard Coverage",
    description: "Comprehensive coverage for individuals and families",
    price: 299,
    deductible: 1500,
    features: [
      "Primary care visits",
      "Emergency services",
      "Prescription coverage (generic and brand)",
      "Specialist visits ($25 copay)"
    ],
    notIncluded: [
      "Dental and vision"
    ],
    isPopular: true
  },
  {
    id: "premium",
    name: "Premium Coverage",
    description: "Complete healthcare solution with maximum benefits",
    price: 429,
    deductible: 750,
    features: [
      "Primary care visits",
      "Emergency services",
      "Prescription coverage (all medications)",
      "Specialist visits ($15 copay)",
      "Dental and vision included"
    ]
  }
];
