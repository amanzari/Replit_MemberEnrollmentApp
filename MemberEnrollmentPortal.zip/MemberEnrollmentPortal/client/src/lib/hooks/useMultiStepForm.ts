import { useState, useEffect } from "react";

interface Step {
  id: string;
  title: string;
  component: React.ReactNode;
}

export function useMultiStepForm(steps: Step[]) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  
  useEffect(() => {
    const form = document.querySelector('form');
    if (!form) return;
    
    const handleGoToStep = (e: Event) => {
      const customEvent = e as CustomEvent;
      const step = customEvent.detail?.step;
      
      if (typeof step === 'number' && step >= 0 && step < steps.length) {
        setCurrentStepIndex(step);
      }
    };
    
    form.addEventListener('goto-step', handleGoToStep);
    
    return () => {
      form.removeEventListener('goto-step', handleGoToStep);
    };
  }, [steps.length]);
  
  function next() {
    setCurrentStepIndex(i => {
      if (i >= steps.length - 1) return i;
      return i + 1;
    });
  }
  
  function back() {
    setCurrentStepIndex(i => {
      if (i <= 0) return i;
      return i - 1;
    });
  }
  
  function goTo(index: number) {
    setCurrentStepIndex(index);
  }
  
  return {
    currentStepIndex,
    currentStep: steps[currentStepIndex],
    steps,
    next,
    back,
    goTo,
    isFirstStep: currentStepIndex === 0,
    isLastStep: currentStepIndex === steps.length - 1
  };
}
