CREATE TABLE "enrollments" (
	"id" serial PRIMARY KEY NOT NULL,
	"first_name" text NOT NULL,
	"last_name" text NOT NULL,
	"date_of_birth" date NOT NULL,
	"gender" text NOT NULL,
	"email" text NOT NULL,
	"phone" text NOT NULL,
	"address" text NOT NULL,
	"city" text NOT NULL,
	"state" text NOT NULL,
	"zip_code" text NOT NULL,
	"plan_id" text NOT NULL,
	"height" integer NOT NULL,
	"weight" integer NOT NULL,
	"has_pre_existing_conditions" boolean NOT NULL,
	"pre_existing_conditions" text,
	"uses_tobacco" boolean NOT NULL,
	"beneficiary_name" text NOT NULL,
	"beneficiary_relationship" text NOT NULL,
	"beneficiary_phone" text NOT NULL,
	"beneficiary_email" text,
	"created_at" date NOT NULL,
	"coverage_start_date" date NOT NULL
);
--> statement-breakpoint
CREATE TABLE "insurance_plans" (
	"id" serial PRIMARY KEY NOT NULL,
	"plan_id" text NOT NULL,
	"name" text NOT NULL,
	"description" text NOT NULL,
	"monthly_price" integer NOT NULL,
	"deductible" integer NOT NULL,
	"features" text[] NOT NULL,
	"not_included" text[],
	CONSTRAINT "insurance_plans_plan_id_unique" UNIQUE("plan_id")
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"password" text NOT NULL,
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
