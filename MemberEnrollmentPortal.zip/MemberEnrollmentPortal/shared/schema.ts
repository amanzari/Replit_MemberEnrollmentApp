import { pgTable, text, serial, integer, boolean, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Basic user schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Insurance Plans
export const insurancePlans = pgTable("insurance_plans", {
  id: serial("id").primaryKey(),
  planId: text("plan_id").notNull().unique(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  monthlyPrice: integer("monthly_price").notNull(),
  deductible: integer("deductible").notNull(),
  features: text("features").array().notNull(),
  notIncluded: text("not_included").array(),
});

// Enrollments
export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  // Personal Information
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  dateOfBirth: date("date_of_birth").notNull(),
  gender: text("gender").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  state: text("state").notNull(),
  zipCode: text("zip_code").notNull(),
  
  // Plan Selection
  planId: text("plan_id").notNull(),
  
  // Medical Information
  height: integer("height").notNull(), // in inches
  weight: integer("weight").notNull(), // in pounds
  hasPreExistingConditions: boolean("has_pre_existing_conditions").notNull(),
  preExistingConditions: text("pre_existing_conditions"),
  usesTobacco: boolean("uses_tobacco").notNull(),
  
  // Beneficiary Information
  beneficiaryName: text("beneficiary_name").notNull(),
  beneficiaryRelationship: text("beneficiary_relationship").notNull(),
  beneficiaryPhone: text("beneficiary_phone").notNull(),
  beneficiaryEmail: text("beneficiary_email"),
  
  // Metadata
  createdAt: date("created_at").notNull(),
  coverageStartDate: date("coverage_start_date").notNull(),
});

// Schema for inserting a new enrollment
export const insertEnrollmentSchema = createInsertSchema(enrollments).omit({
  id: true,
  createdAt: true,
  coverageStartDate: true,
});

// Extended validation schema for the client-side forms
export const enrollmentFormSchema = insertEnrollmentSchema.extend({
  dateOfBirth: z.string().min(1, "Date of birth is required"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  zipCode: z.string().min(5, "Please enter a valid zip code"),
  height: z.coerce.number().min(20, "Please enter a valid height"),
  weight: z.coerce.number().min(50, "Please enter a valid weight"),
  hasPreExistingConditions: z.boolean(),
  preExistingConditions: z.string().optional(),
  usesTobacco: z.boolean(),
});

// Step 1 validation schema (personal information)
export const personalInfoSchema = enrollmentFormSchema.pick({
  firstName: true,
  lastName: true,
  dateOfBirth: true,
  gender: true,
  email: true,
  phone: true,
  address: true,
  city: true,
  state: true,
  zipCode: true,
});

// Step 3 validation schema (medical and beneficiary)
export const medicalAndBeneficiarySchema = enrollmentFormSchema.pick({
  height: true,
  weight: true,
  hasPreExistingConditions: true,
  preExistingConditions: true,
  usesTobacco: true,
  beneficiaryName: true,
  beneficiaryRelationship: true,
  beneficiaryPhone: true,
  beneficiaryEmail: true,
});

export type InsertUser = Omit<typeof users.$inferInsert, "id">;
export type InsertEnrollment = z.infer<typeof insertEnrollmentSchema>;
export type Enrollment = typeof enrollments.$inferSelect;
export type InsurancePlan = typeof insurancePlans.$inferSelect;
export type User = typeof users.$inferSelect;
