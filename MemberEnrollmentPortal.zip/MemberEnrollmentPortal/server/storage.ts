import { db } from "./db";
import { eq } from "drizzle-orm";
import { 
  enrollments, 
  insurancePlans, 
  users, 
  type User, 
  type InsertUser, 
  type Enrollment, 
  type InsertEnrollment 
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  saveEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  getEnrollmentById(id: number): Promise<Enrollment | undefined>;
  getEnrollmentByEmail(email: string): Promise<Enrollment | undefined>;
  initializeDatabase(): Promise<void>;
}

export class PostgresStorage implements IStorage {
  async initializeDatabase(): Promise<void> {
    try {
      // Check if we have insurance plans
      const existingPlans = await db.select().from(insurancePlans);
      
      if (existingPlans.length === 0) {
        // Seed the database with initial insurance plans
        await db.insert(insurancePlans).values([
          {
            planId: "basic",
            name: "Basic Coverage",
            description: "Essential health coverage for individuals on a budget",
            monthlyPrice: 199,
            deductible: 2500,
            features: ["Primary care visits", "Emergency services", "Prescription coverage (generic only)"],
            notIncluded: ["Specialist visits ($40 copay)", "Dental and vision"]
          },
          {
            planId: "standard",
            name: "Standard Coverage",
            description: "Comprehensive coverage for individuals and families",
            monthlyPrice: 299,
            deductible: 1500,
            features: ["Primary care visits", "Emergency services", "Prescription coverage (generic and brand)", "Specialist visits ($25 copay)"],
            notIncluded: ["Dental and vision"]
          },
          {
            planId: "premium",
            name: "Premium Coverage",
            description: "Complete healthcare solution with maximum benefits",
            monthlyPrice: 429,
            deductible: 750,
            features: ["Primary care visits", "Emergency services", "Prescription coverage (all medications)", "Specialist visits ($15 copay)", "Dental and vision included"]
          }
        ]);
        
        console.log('Database initialized with insurance plans');
      }
    } catch (error) {
      console.error('Error initializing database:', error);
      throw error;
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async saveEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const today = new Date();
    
    // Calculate coverage start date (first day of next month)
    const coverageStartDate = new Date(today);
    coverageStartDate.setMonth(coverageStartDate.getMonth() + 1);
    coverageStartDate.setDate(1);
    
    // Format the dates for PostgreSQL
    const formattedToday = today.toISOString().split('T')[0];
    const formattedCoverageStartDate = coverageStartDate.toISOString().split('T')[0];
    
    const result = await db.insert(enrollments).values({
      ...insertEnrollment,
      createdAt: formattedToday,
      coverageStartDate: formattedCoverageStartDate
    }).returning();
    
    return result[0];
  }

  async getEnrollmentById(id: number): Promise<Enrollment | undefined> {
    const result = await db.select().from(enrollments).where(eq(enrollments.id, id));
    return result[0];
  }

  async getEnrollmentByEmail(email: string): Promise<Enrollment | undefined> {
    const result = await db.select().from(enrollments).where(eq(enrollments.email, email));
    return result[0];
  }
}

// Memory storage implementation kept for fallback if needed
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private enrollments: Map<number, Enrollment>;
  currentUserId: number;
  currentEnrollmentId: number;

  constructor() {
    this.users = new Map();
    this.enrollments = new Map();
    this.currentUserId = 1;
    this.currentEnrollmentId = 1;
  }

  async initializeDatabase(): Promise<void> {
    // No initialization needed for memory storage
    return Promise.resolve();
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async saveEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const id = this.currentEnrollmentId++;
    const today = new Date();
    
    // Calculate coverage start date (first day of next month)
    const coverageStartDate = new Date(today);
    coverageStartDate.setMonth(coverageStartDate.getMonth() + 1);
    coverageStartDate.setDate(1);
    
    // Format the dates as strings for consistency with PostgreSQL
    const formattedToday = today.toISOString().split('T')[0];
    const formattedCoverageStartDate = coverageStartDate.toISOString().split('T')[0];
    
    const enrollment: Enrollment = { 
      ...insertEnrollment, 
      id,
      createdAt: formattedToday,
      coverageStartDate: formattedCoverageStartDate
    };
    
    this.enrollments.set(id, enrollment);
    return enrollment;
  }

  async getEnrollmentById(id: number): Promise<Enrollment | undefined> {
    return this.enrollments.get(id);
  }

  async getEnrollmentByEmail(email: string): Promise<Enrollment | undefined> {
    return Array.from(this.enrollments.values()).find(
      (enrollment) => enrollment.email === email
    );
  }
}

// Use PostgreSQL storage by default, fallback to MemStorage if no database connection
export const storage = new PostgresStorage();
