import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { Pool } from 'pg';
import * as schema from '../shared/schema';

// Function to run the database migrations
export async function runMigrations() {
  try {
    console.log('Starting database migration...');
    
    if (!process.env.DATABASE_URL) {
      throw new Error('DATABASE_URL environment variable is not set');
    }
    
    // Create a PostgreSQL connection
    const pool = new Pool({
      connectionString: process.env.DATABASE_URL,
    });
    
    // Initialize drizzle with the connection
    const db = drizzle(pool, { schema });
    
    // Create the database schema
    console.log('Creating database schema...');
    await migrate(db, { migrationsFolder: './migrations' });
    
    // Seed with initial data if needed
    console.log('Checking for initial data...');
    
    // Check if insurance plans exist
    const existingPlans = await db.select().from(schema.insurancePlans);
    
    if (existingPlans.length === 0) {
      console.log('Seeding initial insurance plans...');
      
      // Insert default insurance plans
      await db.insert(schema.insurancePlans).values([
        {
          planId: "basic",
          name: "Basic Coverage",
          description: "Essential health coverage for individuals on a budget",
          monthlyPrice: 199,
          deductible: 2500,
          features: ["Primary care visits", "Emergency services", "Prescription coverage (generic only)"],
          notIncluded: ["Specialist visits ($40 copay)", "Dental and vision"]
        },
        {
          planId: "standard",
          name: "Standard Coverage",
          description: "Comprehensive coverage for individuals and families",
          monthlyPrice: 299,
          deductible: 1500,
          features: ["Primary care visits", "Emergency services", "Prescription coverage (generic and brand)", "Specialist visits ($25 copay)"],
          notIncluded: ["Dental and vision"]
        },
        {
          planId: "premium",
          name: "Premium Coverage",
          description: "Complete healthcare solution with maximum benefits",
          monthlyPrice: 429,
          deductible: 750,
          features: ["Primary care visits", "Emergency services", "Prescription coverage (all medications)", "Specialist visits ($15 copay)", "Dental and vision included"]
        }
      ]);
      
      console.log('Initial data seeded successfully');
    }
    
    await pool.end();
    console.log('Migration completed successfully');
    
    return true;
  } catch (error) {
    console.error('Migration failed:', error);
    throw error;
  }
}

// This function can be used to run migrations from the command line
export async function runMigrationsFromCommandLine() {
  try {
    await runMigrations();
    console.log('Migration completed successfully from command line');
    return true;
  } catch (error) {
    console.error('Migration script failed from command line:', error);
    throw error;
  }
}