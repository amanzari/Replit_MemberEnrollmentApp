import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertEnrollmentSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  /**
   * Submit enrollment endpoint
   */
  app.post("/api/enrollments", async (req, res) => {
    try {
      // Validate request body
      const parseResult = insertEnrollmentSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        const validationError = fromZodError(parseResult.error);
        return res.status(400).json({ 
          message: "Validation error", 
          errors: validationError.details 
        });
      }
      
      // Process the enrollment data
      const enrollmentData = parseResult.data;
      
      // Check if there's already an enrollment with this email
      const existingEnrollment = await storage.getEnrollmentByEmail(enrollmentData.email);
      if (existingEnrollment) {
        return res.status(409).json({ 
          message: "An enrollment with this email already exists" 
        });
      }
      
      // Save the enrollment
      const enrollment = await storage.saveEnrollment(enrollmentData);
      
      // Return the created enrollment
      return res.status(201).json({
        id: enrollment.id,
        firstName: enrollment.firstName,
        lastName: enrollment.lastName,
        email: enrollment.email,
        coverageStartDate: enrollment.coverageStartDate
      });
    } catch (error) {
      console.error("Error processing enrollment:", error);
      
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ 
          message: "Validation error", 
          errors: validationError.details 
        });
      }
      
      return res.status(500).json({ message: "An error occurred while processing your enrollment" });
    }
  });

  /**
   * Get enrollment status
   */
  app.get("/api/enrollments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id, 10);
      
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid enrollment ID" });
      }
      
      const enrollment = await storage.getEnrollmentById(id);
      
      if (!enrollment) {
        return res.status(404).json({ message: "Enrollment not found" });
      }
      
      return res.status(200).json({
        id: enrollment.id,
        firstName: enrollment.firstName,
        lastName: enrollment.lastName,
        email: enrollment.email,
        planId: enrollment.planId,
        coverageStartDate: enrollment.coverageStartDate
      });
    } catch (error) {
      console.error("Error retrieving enrollment:", error);
      return res.status(500).json({ message: "An error occurred while retrieving the enrollment" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
